﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Media;

namespace Defects
{
    public class SeverityColorConverter : IValueConverter
    {
        public SolidColorBrush HighPriorityColor { get; set; }
        public SolidColorBrush DefaultAndLowPriorityColor { get; set; }



        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            try
            {
                var data = value + "";
                var dataValue = double.Parse(data);
                if (dataValue > 5)
                {
                    return HighPriorityColor;
                }
                return DefaultAndLowPriorityColor;
            }
            catch (Exception ex)
            {
                return DefaultAndLowPriorityColor;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value;
        }
    }
}
