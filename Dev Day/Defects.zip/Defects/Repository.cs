﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using Windows.Storage;
using Microsoft.WindowsAzure.MobileServices;
using SQLite;

namespace Defects
{
    public class Repository
    {
        public static MobileServiceClient MobileService = new MobileServiceClient(
            "https://<yourwams>.azure-mobile.net/",
            "<yourapplicationkey>");

        public SQLiteAsyncConnection Connect = new SQLiteAsyncConnection(Path.Combine(ApplicationData.Current.LocalFolder.Path, "defects.db"), true);

        public async Task Initialize()
        {
            await Connect.CreateTableAsync<Defect>();
            await Connect.CreateTableAsync<DefectType>();
        }


        public async Task<IEnumerable<DefectType>> LoadTypes()
        {
            return await Connect.Table<DefectType>().ToListAsync();
        }

        public async Task<IEnumerable<Defect>> LoadCurrentDefects()
        {
            return await Connect.Table<Defect>().ToListAsync();
        }


        public async Task SaveDefect(Defect newDefect)
        {
            await Connect.InsertAsync(newDefect);
        }

        public async Task SyncDefectTypes()
        {
            // Retrieve the last updated value for items in the defect type table
            var localDTypes = Connect.Table<DefectType>();
            var types = await (from dtype in localDTypes
                               orderby dtype.LastUpdated descending
                               select dtype).FirstOrDefaultAsync();
            var updated = types != null ? types.LastUpdated : DateTime.MinValue;

            // Retrieve updated defect types from WAMS and add them to the local db
            var newTypes = await (from dtype in MobileService.GetTable<DefectType>()
                                  where dtype.LastUpdated > updated
                                  select dtype).ToListAsync();
            await Connect.InsertAllAsync(newTypes);
        }


        public async Task SyncDefects()
        {
            // Retrieve all defects that haven't been sync'd
            var defs = await Connect.Table<Defect>().ToListAsync();
            var defects = MobileService.GetTable<Defect>();

            foreach (var defect in defs)
            {
                // Upload the photo
                await UploadPhoto(defect);
                // Upload the defect
                await defects.InsertAsync(defect);
                // Remove the local copy
                await Connect.DeleteAsync(defect);
            }
        }




        //public async Task<IEnumerable<DefectType>> LoadTypes()
        //{
        //    return await MobileService.GetTable<DefectType>().ToListAsync();
        //}

        //public async Task SaveDefect(Defect newDefect)
        //{
        //    var defects = MobileService.GetTable<Defect>();
        //    await defects.InsertAsync(newDefect);
        //}

        //public async Task<IEnumerable<Defect>> LoadCurrentDefects()
        //{
        //    return await MobileService.GetTable<Defect>().ToListAsync();
        //}

        public async Task<bool> UploadPhoto(Defect defect)
        {
            var sas = await LoadUploadSas(defect.LocalPhotoPath);
            var url = sas.Path + "?" + sas.Sas;
            var strm = IsolatedStorageFile.GetUserStoreForApplication().OpenFile(defect.LocalPhotoPath, FileMode.Open, FileAccess.Read);
            var ok = await Task.Run(() =>
            {
                try
                {
                    var uploader = new CloudBlobUploader(strm, url);
                    var reset = new ManualResetEvent(false);
                    uploader.UploadFinished = (finishedOk) => reset.Set();
                    uploader.StartUpload();
                    reset.WaitOne();

                    return true;
                }
                catch (Exception ex)
                {
                    return false;
                }
            });
            if (ok)
            {
                defect.PhotoUrl = sas.Path;
            }
            return ok;
        }

        public async Task<SasInfo> LoadUploadSas(string photo)
        {
            return await MobileService.InvokeApiAsync<SasInfo>("getblobaccess", HttpMethod.Get, new Dictionary<string, string> { { "resourceName", photo } });
        }

        //************************************************************************************

        public class SasInfo
        {
            public string Sas { get; set; }
            public string Path { get; set; }
        }

        //************************************************************************************

        public class CloudBlobUploader
        {
            private const long ChunkSize = 16384;// 4194304;

            private Stream fileStream;
            private long dataLength;
            private long dataSent;

            private bool useBlocks;
            private string currentBlockId;
            private IList<string> blockIds = new List<string>();

            private string uploadUrl;

            public CloudBlobUploader(Stream fileStream, string uploadUrl)
            {
                this.fileStream = fileStream;
                this.uploadUrl = uploadUrl;
                //                this.StorageCredentials = credentials;
                this.dataLength = this.fileStream.Length;
                this.dataSent = 0;

                // Upload the blob in smaller blocks if it's a "big" file.
                this.useBlocks = (this.dataLength - this.dataSent) > ChunkSize;
            }

            public Action<bool> UploadFinished;
            public Action<double> UploadProgress;

            //public IStorageCredentials StorageCredentials { get; set; }

            public void StartUpload()
            {
                try
                {

                    if (uploadUrl == null)
                    {
                        this.RaiseUploadFinished(false, null);
                    }
                    var uriBuilder = new UriBuilder(this.uploadUrl);

                    // Set a timeout query string parameter.
                    uriBuilder.Query = string.Format(
                        CultureInfo.InvariantCulture,
                        "{0}{1}",
                        uriBuilder.Query.TrimStart('?'),
                        string.IsNullOrEmpty(uriBuilder.Query) ? "timeout=10000" : "&timeout=10000");

                    if (this.useBlocks)
                    {
                        // Encode the block name and add it to the query string.
                        this.currentBlockId = Convert.ToBase64String(Encoding.UTF8.GetBytes(Guid.NewGuid().ToString()));
                        uriBuilder.Query = string.Format(
                            CultureInfo.InvariantCulture,
                            "{0}&comp=block&blockid={1}",
                            uriBuilder.Query.TrimStart('?'),
                            this.currentBlockId);
                    }

                    // With or without using blocks, we'll make a PUT request with the data.
                    var request = WebRequest.CreateHttp(uriBuilder.Uri);
                    request.Method = "PUT";
                    request.BeginGetRequestStream(this.WriteToStreamCallback, request);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    this.RaiseUploadFinished(false, ex);
                }
            }

            private void WriteToStreamCallback(IAsyncResult asynchronousResult)
            {
                try
                {
                    var request = (HttpWebRequest)asynchronousResult.AsyncState;
                    using (var requestStream = request.EndGetRequestStream(asynchronousResult))
                    {
                        var buffer = new byte[4096];
                        var bytesRead = 0;
                        var tempTotal = 0;
                        this.fileStream.Position = this.dataSent;

                        while (((bytesRead = this.fileStream.Read(buffer, 0, buffer.Length)) != 0) &&
                                (tempTotal + bytesRead < ChunkSize))
                        {
                            requestStream.Write(buffer, 0, bytesRead);
                            requestStream.Flush();

                            this.dataSent += bytesRead;
                            tempTotal += bytesRead;

                            RaiseProgress();
                        }
                    }



                    //if (this.StorageCredentials != null)
                    //{
                    //    request.Headers["x-ms-version"] = "2009-09-19";
                    //    request.Headers["x-ms-blob-type"] = "BlockBlob";

                    //    this.StorageCredentials.SignRequest(request, tempTotal);
                    //}

                    request.BeginGetResponse(this.ReadHttpResponseCallback, request);
                }
                catch (Exception exception)
                {
                    this.RaiseUploadFinished(false, exception);
                }
            }

            private int RaisingProgress;
            private void RaiseProgress()
            {
                if (Interlocked.CompareExchange(ref RaisingProgress, 1, 0) == 1) return;
                Task.Run(() =>
                {
                    try
                    {
                        var progress = 100 * dataSent / dataLength;
                        RaiseUploadProgress(progress);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex.Message);
                    }
                    finally
                    {
                        Interlocked.Exchange(ref RaisingProgress, 0);
                    }
                });
            }

            private void ReadHttpResponseCallback(IAsyncResult asynchronousResult)
            {
                try
                {
                    var request = (HttpWebRequest)asynchronousResult.AsyncState;
                    var response = (HttpWebResponse)request.EndGetResponse(asynchronousResult);

                    if (this.useBlocks)
                    {
                        this.blockIds.Add(this.currentBlockId);
                    }

                    // If there is more data, send another request.
                    if (this.dataSent < this.dataLength)
                    {
                        this.StartUpload();
                    }
                    else
                    {
                        this.fileStream.Dispose();

                        if (this.useBlocks)
                        {
                            // Commit the blocks into the blob.
                            this.PutBlockList();
                        }
                        else
                        {
                            this.RaiseUploadFinished(true, null);
                        }
                    }
                }
                catch (Exception exception)
                {
                    this.RaiseUploadFinished(false, exception);
                }
            }

            private void PutBlockList()
            {
                try
                {
                    if (uploadUrl == null)
                    {
                        this.RaiseUploadFinished(false, null);
                    }
                    var uriBuilder = new UriBuilder(this.uploadUrl);
                    uriBuilder.Query = string.Format(
                        CultureInfo.InvariantCulture,
                        "{0}{1}",
                        uriBuilder.Query.TrimStart('?'),
                        string.IsNullOrEmpty(uriBuilder.Query) ? "comp=blocklist" : "&comp=blocklist");

                    var request = WebRequest.CreateHttp(uriBuilder.Uri);
                    request.Method = "PUT";

                    // x-ms-version is required for put block list
                    request.Headers["x-ms-version"] = "2009-09-19";

                    request.BeginGetRequestStream(this.BlockListWriteToStreamCallback, request);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    this.RaiseUploadFinished(false, ex);

                }

            }

            private void BlockListWriteToStreamCallback(IAsyncResult asynchronousResult)
            {
                try
                {
                    var request = (HttpWebRequest)asynchronousResult.AsyncState;
                    using (var requestStream = request.EndGetRequestStream(asynchronousResult))
                    {
                        var document =
                            new XDocument(new XElement("BlockList",
                                from blockId in this.blockIds
                                select new XElement("Uncommitted", blockId)));
                        var writer = XmlWriter.Create(requestStream, new XmlWriterSettings { Encoding = Encoding.UTF8 });
                        var length = 0L;

                        document.Save(writer);
                        writer.Flush();

                        length = requestStream.Length;
                    }
                    //if (this.StorageCredentials != null)
                    //{
                    //    request.Headers["x-ms-version"] = "2009-09-19";

                    //    this.StorageCredentials.SignRequest(request, length);
                    //}

                    request.BeginGetResponse(this.BlockListReadHttpResponseCallback, request);
                }
                catch (Exception exception)
                {
                    this.RaiseUploadFinished(false, exception);
                }
            }

            private void BlockListReadHttpResponseCallback(IAsyncResult asynchronousResult)
            {
                try
                {
                    var request = (HttpWebRequest)asynchronousResult.AsyncState;
                    var response = (HttpWebResponse)request.EndGetResponse(asynchronousResult);

                    this.RaiseUploadFinished(true, null);
                }
                catch (Exception exception)
                {
                    this.RaiseUploadFinished(false, exception);
                }
            }
            private void RaiseUploadProgress(double response)
            {
                var uploadfinished = this.UploadProgress;
                if (uploadfinished != null)
                {
                    uploadfinished(response);
                }
            }

            private void RaiseUploadFinished(bool response, Exception exception)
            {
                var uploadfinished = this.UploadFinished;
                if (uploadfinished != null)
                {
                    uploadfinished(response);
                }
            }
        }

    }
}