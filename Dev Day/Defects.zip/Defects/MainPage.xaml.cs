﻿using System;
using System.Windows.Navigation;

namespace Defects
{
    public partial class MainPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // Sample code to localize the ApplicationBar
            //BuildLocalizedApplicationBar();
        }

        public MainViewModel ViewModel
        {
            get
            {
                return DataContext as MainViewModel;
            }
        }

        private void AddDefectClick(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/AddDefectPage.xaml", UriKind.Relative));
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            ViewModel.Load();
        }

        private void SyncClick(object sender, EventArgs e)
        {
            ViewModel.Sync();
        }
    }

    

}