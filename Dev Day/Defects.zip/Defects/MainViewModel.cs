﻿using System.Collections.ObjectModel;

namespace Defects
{
    public class MainViewModel : BaseViewModel
    {
        private readonly ObservableCollection<Defect> defects
            = new ObservableCollection<Defect>();

        public ObservableCollection<Defect> Defects
        {
            get
            {
                return defects;
            }
        }

        public async  void Load()
        {
            var defects = await Repository.LoadCurrentDefects();
            Defects.Clear();
            foreach (var defect in defects)
            {
                Defects.Add(defect);
            }
        }

        public async void Sync()
        {
            await Repository.SyncDefectTypes();
            await Repository.SyncDefects();
            Load();
        }
    }
}