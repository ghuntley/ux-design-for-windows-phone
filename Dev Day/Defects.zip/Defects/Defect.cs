﻿using System;
using System.ComponentModel;
using System.IO;
using System.IO.IsolatedStorage;
using System.Runtime.CompilerServices;
using System.Windows.Media.Imaging;
using SQLite;

namespace Defects
{
    public class Defect : INotifyPropertyChanged
    {
        public int Id { get; set; }

        [PrimaryKey]
        public string UniqueId { get; set; }

        public string Title { get; set; }

        public string DefectType { get; set; }

        public int Severity { get; set; }

        public string PhotoUrl { get; set; }

        public Defect()
        {
            UniqueId = Guid.NewGuid().ToString();
            PhotoUrl = string.Empty;
            Title = string.Empty;
            DefectType = string.Empty;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }


        public string LocalPhotoPath
        {
            get
            {
                return UniqueId + ".jpg";
            }
        }


        public void Refresh()
        {
            OnPropertyChanged("Photo");
        }

        public BitmapImage Photo
        {
            get
            {
                if (string.IsNullOrWhiteSpace(PhotoUrl))
                {
                    var stor = IsolatedStorageFile.GetUserStoreForApplication();
                    var file = LocalPhotoPath;
                    if (stor.FileExists(file))
                    {
                        var bmp = new BitmapImage();
                        var strm = stor.OpenFile(file, FileMode.Open, FileAccess.Read);
                        bmp.SetSource(strm);
                        return bmp;
                    }
                    return null;
                }
                else
                {
                    return new BitmapImage(new Uri(PhotoUrl));
                }
            }
        }

    }
}