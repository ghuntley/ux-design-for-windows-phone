﻿namespace Defects
{
    public class ViewModelLocator
    {
        private Repository Repository { get; set; }

        public ViewModelLocator()
        {
            Repository = new Repository();
            Repository.Initialize();
        }


        public MainViewModel Main
        {
            get
            {
                return new MainViewModel { Repository = Repository };
            }
        }

        public AddDefectViewModel AddDefect
        {
            get
            {
                return new AddDefectViewModel { Repository = Repository };
            }
        }
    }
}