﻿using System.Collections.ObjectModel;
using System.Threading.Tasks;

namespace Defects
{
    public class AddDefectViewModel : BaseViewModel
    {
        public AddDefectViewModel()
        {
            NewDefect = new Defect();
        }

        public Defect NewDefect { get; set; }

        private readonly ObservableCollection<DefectType> defectTypes
            = new ObservableCollection<DefectType>();

        public ObservableCollection<DefectType> DefectTypes
        {
            get
            {
                return defectTypes;
            }
        }

        public async Task Load()
        {
            var defecttypes = await Repository.LoadTypes();
            foreach (var defecttype in defecttypes)
            {
                DefectTypes.Add(defecttype);
            }
        }

        public async Task Save()
        {
            await Repository.SaveDefect(NewDefect);
        }
    }
}