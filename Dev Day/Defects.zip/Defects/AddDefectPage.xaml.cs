﻿using System;
using System.IO;
using System.IO.IsolatedStorage;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Tasks;

namespace Defects
{
    public partial class AddDefectPage
    {
        private CameraCaptureTask camera;

        public AddDefectPage()
        {
            InitializeComponent();

            camera = new CameraCaptureTask();
            camera.Completed += CameraCompleted;
        }

        private async void CameraCompleted(object sender, PhotoResult e)
        {
            if (e.TaskResult == TaskResult.OK)
            {
                var store = IsolatedStorageFile.GetUserStoreForApplication();
                if (store.FileExists(ViewModel.NewDefect.LocalPhotoPath))
                {
                    store.DeleteFile(ViewModel.NewDefect.LocalPhotoPath);
                }
                using (var file = store.OpenFile(ViewModel.NewDefect.LocalPhotoPath, FileMode.Create, FileAccess.Write))
                {
                    await e.ChosenPhoto.CopyToAsync(file);
                }
                ViewModel.NewDefect.Refresh();
            }
        }

        private void PhotoClick(object sender, EventArgs e)
        {
            camera.Show();
        }



        public AddDefectViewModel ViewModel
        {
            get
            {
                return DataContext as AddDefectViewModel;
            }
        }

        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            if (e.NavigationMode == NavigationMode.New)
            {
                await ViewModel.Load();
            }
        }


        private void DefectTypeChanged(object sender, SelectionChangedEventArgs e)
        {
            var dType = (sender as ListPicker).SelectedItem as DefectType;
            if (dType == null) return;
            ViewModel.NewDefect.DefectType = dType.Name;
        }

        private async void SaveClick(object sender, EventArgs e)
        {
            await ViewModel.Save();
            NavigationService.GoBack();
        }
    }
}